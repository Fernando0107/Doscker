import java.util.Scanner;

public class Recursion_1 {

    private static Integer recursion(int n) {
        if (n == 0) return 0;
        return n + recursion(n - 1);
    }
    public static void main(String[] args) {
        int n;
        Scanner user = new Scanner(System.in);
        System.out.println("Ingrese un número: ");
        n = user.nextInt();
        System.out.println(recursion(n));

    }
}

