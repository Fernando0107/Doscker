import java.util.Scanner;

public class Recursion_3 {

    private String recursion(String n) {
        if ((n == null) || (n.length() <= 1)) return n;
        return recursion(n.substring(1)) + n.charAt(0);
    }
    public static void main(String[] args) {
        String n;
        Recursion_3 obj = new Recursion_3();
        Scanner user = new Scanner(System.in);
        System.out.println("Ingrese una palabra: ");
        n = user.nextLine();
        System.out.println("El reverso es: " + obj.recursion(n));

    }
}

