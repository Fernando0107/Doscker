import java.util.Scanner;

public class Recursion_4 {

    private static Integer recursion(int n, int m) {
        if (m==0) return 1;
        return (n*recursion(n, m - 1));
    }
    public static void main(String[] args) {
        int n;
        int m;
        Scanner user = new Scanner(System.in);
        System.out.println("Ingrese el número a elevar: ");
        n = user.nextInt();
        System.out.println("Ingrese la potencia: ");
        m = user.nextInt();
        System.out.println(recursion(n, m));

    }
}

