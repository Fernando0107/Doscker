import java.util.Scanner;

public class Recursion_5 {

    private static boolean recursion(int n) {
        if (n==0) return true;
        if (n==1) return false;
        else {
            n = n - 2;
            return (recursion(n));
        }

    }
    public static void main(String[] args) {
        int n;
        Scanner user = new Scanner(System.in);
        System.out.println("Ingrese un número: ");
        n = user.nextInt();
        if (recursion(n)) System.out.println("El numero: " + n + " es par");
        if (!recursion(n)) System.out.println("El numero: " + n + " no es par");

    }
}


