import java.util.Scanner;

public class Recursion_6 {

    private static Integer recursion(int n) {
        if (n<=1) return n;
        return recursion(n-1) + recursion(n-2);
    }
    public static void main(String[] args) {
        int n;
        int m = 1;
        Scanner user = new Scanner(System.in);
        System.out.println("Ingrese número de elementos: ");
        n = user.nextInt();
        for (int i = 1; i <= n; i++)
            System.out.print(recursion(i)+ " ");

    }
}

