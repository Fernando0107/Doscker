import java.lang.reflect.Array;
import java.util.Scanner;

public class Recursion_7 {

    private static Integer recursion(int m[], int largo, int actual, int siguiente) {
        if (actual > siguiente) {
            actual = m[largo];
            if (largo <= 0) return actual;
            siguiente = m[largo-1];
            return recursion(m, largo-1, actual, siguiente);
        } else {
            if (largo <= 0) return actual;
            siguiente = m[largo-1];
            return recursion(m, largo - 1, actual, siguiente);
        }
    }
    public static void main(String[] args) {
        int menor[] = {5,6,7,9,5,5,4,7,8,87,45,65};
        int largo = menor.length;
        int actual = menor[largo - 1];
        int siguiente = menor[largo-1];


        System.out.println(recursion(menor, largo-1, actual, siguiente));

    }
}

