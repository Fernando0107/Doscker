import java.util.Date; // (https://docs.oracle.com/javase/7/docs/api/)
import java.text.SimpleDateFormat; // (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html)

public class Task{
    
    /* Do not modify */
    private String msg_reminder, notes;
    private Date do_date;
    private int priority = 0;
    private boolean status = false;
    private String pattern = "yyyy-MM-dd";
    private SimpleDateFormat simpleDateFormat;

    /* Task con msg_reminder, prioridad y date*/
    public Task(String msg_reminder, Date do_date, int priority) {
        this.msg_reminder = msg_reminder;
        this.do_date = do_date;
        this.priority = priority;
    }
    /* Task con fecha, prioridad y notas */
    public Task(String msg_reminder, Date do_date, int priority, String notes) {
        this.msg_reminder = msg_reminder;
        this.do_date = do_date;
        this.priority = priority;
        this.notes = notes;

    }
    /* Task con msg_reminder y date */
    public Task(String msg_reminder) {
        this.msg_reminder = msg_reminder;
        this.do_date = getTaskDate();

    }

    public String getNotes(){
        return this.notes;
    }

    public int getPriority(){
        return this.priority;
    }

    public boolean getStatus(){
        return this.status;
    }

    public boolean markAsDone(){
        return this.status = true;
        
    }


    public String getTaskDate(){
        /* Your code here */
        /* Codigo para obtener la fecha de hoy */
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));

        return this.dtf.format(now);

    }

    public String toString(){
        return "Task: " + this.msg_reminder + " Priority: " + this.priority + " Do Date: " + this.do_date;
    }

}