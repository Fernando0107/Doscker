import java.util.Date; // (https://docs.oracle.com/javase/7/docs/api/)
import java.text.SimpleDateFormat; // (https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html)
import packageName.TaskList;
import packageName.Task;
public class Task{

    /* Llamar Task y TaskList */
    /* No estoy seguro de que este bien la verdad... */
    Task.method();
    TaskList.method();

    Task c = new Task();
    c.method();
    ListTask a = new TaskList();
    a.void();


}